function noConn(){
 alert("আপনার সাথে কানেকশন নাই দয়া করে দ্রুত কানেক্ট করুন এই সার্ভিস নেওয়ার জন্য");
}

function deny(){
 alert("আপনার একাউন্ট টি এখনো সচিব কর্তৃক অনুমোদিত হয়নি দয়া করে দ্রুত অনুমোদন করুন");
}

function show(id){
 document.querySelectorAll('.box').forEach(b=>b.classList.add('hidden'));
 document.getElementById(id).classList.remove('hidden');
}